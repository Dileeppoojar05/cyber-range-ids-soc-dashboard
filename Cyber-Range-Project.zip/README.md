# Cyber Range IDS & SOC Dashboard

## Overview
Cyber Range IDS & SOC Dashboard is a project for monitoring and visualizing security events in a cyber range environment.

## Setup
```bash
pip install -r requirements.txt
```
