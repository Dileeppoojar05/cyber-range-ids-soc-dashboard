import sqlite3
from datetime import datetime

DB_NAME = "cyber.db"

def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()

    c.execute("""
    CREATE TABLE IF NOT EXISTS alerts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT,
        src_ip TEXT,
        attack_type TEXT,
        severity TEXT
    )
    """)

    conn.commit()
    conn.close()

def insert_alert(ip, attack, severity):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()

    c.execute("INSERT INTO alerts (timestamp, src_ip, attack_type, severity) VALUES (?, ?, ?, ?)",
              (datetime.now(), ip, attack, severity))

    conn.commit()
    conn.close()

def fetch_alerts():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()

    c.execute("SELECT * FROM alerts ORDER BY id DESC")
    rows = c.fetchall()

    conn.close()
    return rows
